"""Pydantic schemas for Iskra"""
from pydantic import BaseModel, Field, ConfigDict
from typing import Optional, List
from datetime import datetime

class UserBase(BaseModel):
    username: str = Field(..., min_length=3, max_length=32, pattern=r"^[a-zA-Z0-9_]+$")
    display_name: Optional[str] = Field(None, max_length=64)
    status: Optional[str] = Field(None, max_length=255)
    bio: Optional[str] = None

class UserCreate(UserBase):
    password: str = Field(..., min_length=8, max_length=128)

class UserLogin(BaseModel):
    username: str
    password: str

class UserResponse(UserBase):
    model_config = ConfigDict(from_attributes=True)

    id: int
    iskra_id: str
    avatar_url: Optional[str] = None
    is_online: bool
    last_seen: Optional[datetime] = None
    is_verified: bool
    created_at: datetime
    friends_count: int = 0

class UserProfile(UserResponse):
    public_key: Optional[str] = None

class UserUpdate(BaseModel):
    display_name: Optional[str] = Field(None, max_length=64)
    status: Optional[str] = Field(None, max_length=255)
    bio: Optional[str] = None

class PostBase(BaseModel):
    content: str = Field(..., min_length=1, max_length=5000)
    is_public: bool = True

class PostCreate(PostBase):
    pass

class PostResponse(PostBase):
    model_config = ConfigDict(from_attributes=True)

    id: int
    author_id: int
    author: UserResponse
    image_url: Optional[str] = None
    likes_count: int
    comments_count: int
    created_at: datetime
    is_liked_by_me: bool = False

class CommentCreate(BaseModel):
    content: str = Field(..., min_length=1, max_length=2000)

class CommentResponse(CommentCreate):
    model_config = ConfigDict(from_attributes=True)

    id: int
    author_id: int
    author: UserResponse
    created_at: datetime

class MessageCreate(BaseModel):
    receiver_id: int
    content: str = Field(..., min_length=1, max_length=10000)

class MessageResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    sender_id: int
    receiver_id: int
    content: str
    is_read: bool
    created_at: datetime

class GroupBase(BaseModel):
    name: str = Field(..., min_length=3, max_length=100)
    description: Optional[str] = None
    is_public: bool = True

class GroupCreate(GroupBase):
    pass

class GroupResponse(GroupBase):
    model_config = ConfigDict(from_attributes=True)

    id: int
    owner_id: int
    avatar_url: Optional[str] = None
    members_count: int
    created_at: datetime
    is_member: bool = False
    is_admin: bool = False

class FriendRequestCreate(BaseModel):
    receiver_id: int

class FriendRequestResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    sender_id: int
    sender: UserResponse
    receiver_id: int
    status: str
    created_at: datetime

class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: UserResponse

class SearchResult(BaseModel):
    users: List[UserResponse]
    groups: List[GroupResponse]
