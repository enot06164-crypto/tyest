"""Feed router for Iskra"""
from fastapi import APIRouter
router = APIRouter()
